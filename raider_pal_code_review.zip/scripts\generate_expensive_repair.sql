-- Generate/refresh the “expensive” repair band by doubling the cheap band.
-- Run this in Supabase SQL after you add/update cheap costs.
-- Safe to rerun; uses ON CONFLICT to update existing rows.

insert into item_repair_costs (item_id, component_item_id, quantity, durability_band)
select
  item_id,
  component_item_id,
  quantity * 2 as quantity,
  'expensive' as durability_band
from item_repair_costs
where durability_band = 'cheap'
on conflict (item_id, component_item_id, durability_band) do update
  set quantity = excluded.quantity;



-- Upgrades staging (dev-only)
create table if not exists item_upgrade_costs_stage (
  item_id text not null,
  required_item_id text null,
  component_item_id text not null,
  quantity integer not null check (quantity > 0)
);
-- No PK on staging; easier to import duplicates and clean later.

-- Repair costs staging (matches your live item_repair_costs)
create table if not exists item_repair_costs_stage (
  item_id text not null,
  component_item_id text not null,
  quantity integer not null check (quantity > 0),
  durability_band text not null  -- e.g., 'cheap' | 'expensive'
);


-- Upgrades upsert
insert into item_upgrade_costs (item_id, component_item_id, required_item_id, quantity)
select item_id, component_item_id, required_item_id, quantity
from item_upgrade_costs_stage
on conflict (item_id, component_item_id) do update
  set required_item_id = excluded.required_item_id,
      quantity = excluded.quantity;

-- Repairs upsert
insert into item_repair_costs (item_id, component_item_id, quantity, durability_band)
select item_id, component_item_id, quantity, durability_band
from item_repair_costs_stage
on conflict (item_id, component_item_id, durability_band) do update
  set quantity = excluded.quantity;

-- (Optional) Clear staging after a successful run
truncate table item_upgrade_costs_stage;
truncate table item_repair_costs_stage;
