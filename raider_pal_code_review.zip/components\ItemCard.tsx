// components/ItemCard.tsx
import Image from "next/image";
import Link from "next/link";

export type ItemCardProps = {
  item: {
    id: string;
    name: string | null;
    icon?: string | null;
    rarity?: string | null;
    value?: number | null;
    item_type?: string | null;
    loot_area?: string | null;
    workbench?: string | null;
  };
  onClick?: () => void;
  action?: React.ReactNode;
  ariaControls?: string;
};

export function rarityClasses(rarity?: string | null) {
  switch (rarity) {
    case "Common":
      return "border-border-subtle bg-surface-card/70";
    case "Uncommon":
      return "border-emerald-600/70 bg-emerald-950/40";
    case "Rare":
      return "border-brand-cyan/70 bg-brand-cyan/10";
    case "Epic":
      return "border-purple-600/70 bg-purple-950/40";
    case "Legendary":
      return "border-amber-500/80 bg-amber-950/40";
    default:
      return "border-border-subtle bg-surface-card/60";
  }
}

/** Reusable rarity pill so cards + modals stay consistent */
export function RarityBadge({ rarity }: { rarity?: string | null }) {
  if (!rarity) return null;

  return (
    <span
      className={`text-[10px] uppercase tracking-wide text-warm border rounded px-1.5 py-0.5 bg-panel-texture font-condensed ${rarityClasses(
        rarity
      )}`}
    >
      {rarity}
    </span>
  );
}

export function ItemCard({ item, onClick, action, ariaControls }: ItemCardProps) {
  const inner = (
    <div
      className={`group flex items-center gap-3 rounded-lg border px-3 py-2.5 text-sm hover:border-[#4fc1e9]/70 hover:bg-slate-900 transition-colors ${rarityClasses(
        item.rarity
      )}`}
    >
      {/* Icon */}
      {item.icon && (
        <Image
          src={item.icon}
          alt={item.name ?? "Item icon"}
          width={36}
          height={36}
          sizes="36px"
          loading="lazy"
          className="h-9 w-9 rounded border border-slate-700 bg-slate-900 object-contain"
        />
      )}

      {/* Main text */}
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <span className="truncate font-condensed font-semibold text-warm">
            {item.name ?? "Unknown item"}
          </span>
          <RarityBadge rarity={item.rarity} />
        </div>

        <div className="mt-0.5 flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] text-warm-muted font-medium">
          {item.item_type && (
            <span className="inline-flex items-center gap-1">
              <span className="w-1 h-1 rounded-full bg-slate-500" />
              {item.item_type}
            </span>
          )}
          {item.loot_area && (
            <span className="inline-flex items-center gap-1">
              <span className="w-1 h-1 rounded-full bg-[#4fc1e9]" />
              {item.loot_area}
            </span>
          )}
          {item.workbench && (
            <span className="inline-flex items-center gap-1">
              <span className="w-1 h-1 rounded-full bg-amber-500/80" />
              WB: {item.workbench}
            </span>
          )}
        </div>
      </div>

      {/* Value */}
      {(item.value != null || action) && (
        <div className="ml-2 flex flex-col items-end gap-2 text-right text-xs text-warm font-medium">
          {item.value != null && (
            <div>
              <div className="font-semibold">{item.value}</div>
              <div className="text-[10px] text-warm-muted font-medium">value</div>
            </div>
          )}
          {action && (
            <div onClick={(e) => e.stopPropagation()}>{action}</div>
          )}
        </div>
      )}
    </div>
  );

  if (onClick) {
    return (
      <div
        role="button"
        tabIndex={0}
        aria-controls={ariaControls}
        onClick={onClick}
        onKeyDown={(e) => {
          if (e.key === "Enter" || e.key === " ") {
            e.preventDefault();
            onClick();
          }
        }}
        className="text-left w-full focus:outline-none min-w-0"
      >
        {inner}
      </div>
    );
  }

  return (
    <Link href={`/items/${item.id}`} className="block">
      {inner}
    </Link>
  );
}
